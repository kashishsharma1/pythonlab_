#unpacking a tuple
t=(1,2,5,6,7,'g','h')
for i in range(0,7):
    print(t[i])
