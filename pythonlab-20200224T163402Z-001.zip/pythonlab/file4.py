# ADD  ELEMENTS TO TUPLE
y=tuple(map(int,input().split(",")))
z=tuple(map(int,input().split(",")))
y+=z
print(y)
