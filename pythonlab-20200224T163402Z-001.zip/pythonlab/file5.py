#convert tuple to string 
y=('o','h',8,9,'i','d',3,4)
w=str(y)
print(w,type(w))
