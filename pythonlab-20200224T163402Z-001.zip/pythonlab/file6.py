t=(1,3,6,[])
d=eval(str(t))
d[-1].append(100)
print(t)
print(d)
    
