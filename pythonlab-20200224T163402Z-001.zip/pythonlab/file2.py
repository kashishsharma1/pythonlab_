# tuple using different data types
m=eval('input()')
print(m)
n=tuple(map(int,input().split(" ")))
print(n)
